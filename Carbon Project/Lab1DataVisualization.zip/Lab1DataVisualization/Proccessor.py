import re
from CarbonEmissionClass import CarbonEmissionClass
from AnnualTemperature import AnnualTemperature


carbon_emission = open('Co2.html', 'r')
carbon_data = re.compile('\d*\.?\d+')
a = CarbonEmissionClass()

temperature = open('Temperature.html', 'r')
temp_data = re.compile('[+-]?\d*\.?\d+')
b = AnnualTemperature()

class Proccessor():
    def __init__(self):
        self.count = 0
        self.avg_dict = {}
        self.carbon_result_dict = {}
        self.months = 0
        self.current_year = 0
        #Temp Data
        self.count_temp = 0
        
    def LoadCarbonData(self):
        for i in carbon_emission:
            if carbon_data.findall(i) != [] and carbon_data.findall(i) != ['2']:
                carbon =  carbon_data.findall(i)
                a.__add__(carbon[0], carbon[1], carbon[3])
    def getCarbonData(self):
        for (key1, key2), value in a.getCarbonDict().items():
            if key1 not in self.carbon_result_dict:
                self.carbon_result_dict[key1] = a.getYearAvg(key1)                   
        return self.carbon_result_dict
        

    def LoadTempData(self):
        for i in temperature:
            # if temp_data.findall(i) != [] and temp_data.findall(i) != ['1961','1990'] and temp_data.findall(i) != ['2']:
            if len(temp_data.findall(i)) == 4:
                temp =  temp_data.findall(i)
                b.__add__(temp[0], temp[1])
    def getTempData(self):
        return b.getTempDict()
    def closeCarbonFile(self):
        carbon_emission.close()
    def closeTempFile(self):
        temperature.close()
           



    
